export interface ContentState {
    statusTitle: string;
    statusDescription: string;
    progress: number;
    estimatedTime: string;
    driverOrRestaurantName: string;
    iconName: string;
    secondaryIconName?: string;
    orderNumber?: string;
    primaryColorHex: string;
}
export interface RideFoodNotificationType {
    start(type: 'ride' | 'food', attributes: Record<string, any>, contentState: ContentState): Promise<string>;
    update(activityId: string, contentState: ContentState): Promise<void>;
    end(activityId: string): Promise<void>;
}
declare const _default: RideFoodNotificationType;
export default _default;
//# sourceMappingURL=index.d.ts.map